export class PersonModel {
  id: number;
  nombre: string;
  especie: string;
  imagen: string;
  estatus: string;
  genero:string;
  origen:string;


  constructor(){
    this.id = 0;
    this.nombre = "";
    this.especie = "";
    this.imagen = "";
    this.estatus = "";
    this.genero = "";
    this.origen = "";
  }
}
