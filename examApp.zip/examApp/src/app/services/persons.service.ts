import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PersonsService {

  private url = 'https://rickandmortyapi.com/api/character/';

  constructor(private http: HttpClient) { }

  ngOnInit() {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.

  }

  getPersons(){
    return this.http.get(this.url);
  }

  getPerson(id: number){
    return this.http.get(this.url + id);
  }
}
