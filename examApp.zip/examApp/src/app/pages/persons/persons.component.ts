import { Component, OnInit } from '@angular/core';
import { PersonsService } from '../../services/persons.service';
import { PersonModel } from '../../models/person.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-persons',
  templateUrl: './persons.component.html',
  styleUrls: ['./persons.component.css']
})
export class PersonsComponent implements OnInit {
  constructor(private personsService: PersonsService,
              private router: Router) { }

 Person = new PersonModel();
 Persons: PersonModel[] = [];

  ngOnInit() {
    this.personsService.getPersons()
    .subscribe(resp => {
      let results;
      results = Object.values(resp)[1];

      //console.log(results);

      for(let i=0; i<results.length; i++)
      {

        this.Person = new PersonModel();
        this.Person.id = results[i].id;
        this.Person.nombre = results[i].name;
        this.Person.estatus = results[i].status;
        this.Person.especie = results[i].species;
        this.Person.imagen = results[i].image;

        this.Persons.push(this.Person);
      }

    });
  }

  verPerson(id:number){
    this.router.navigate( ['/person',id] );
  }
}
