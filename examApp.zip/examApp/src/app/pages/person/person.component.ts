import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PersonsService } from '../../services/persons.service';
import { PersonModel } from '../../models/person.model';

@Component({
  selector: 'app-person',
  templateUrl: './person.component.html',
  styleUrls: ['./person.component.css']
})
export class PersonComponent  {

  Person = new PersonModel();

  constructor(private activatedRoute: ActivatedRoute,
              private personsService: PersonsService) {

    this.activatedRoute.params.subscribe( params => {
      this.personsService.getPerson(params['id'])
      .subscribe(resp => {
      let results;

      results = Object.values(resp);

      this.Person = new PersonModel();
      this.Person.id = results[0];
      this.Person.nombre = results[1];
      this.Person.estatus = results[2];
      this.Person.especie = results[3];
      this.Person.imagen = results[8];
      this.Person.genero = results[5];
      this.Person.origen = results[6].name;

    });
      console.log(this.Person);
    })
  }

  ngOnInit(): void {
  }

}
